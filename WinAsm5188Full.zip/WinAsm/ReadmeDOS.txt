To assemble and link a DOS program from within WinAsm Studio, you must have a Windows compatible 16-bit linker, such as the one in the archive at this URL- http://win32assembly.online.fr/files/Lnk563.exe
Run the archive to unpack Link.exe, rename the Link.exe file to Link16.exe and copy it
into the \masm32\bin folder.
